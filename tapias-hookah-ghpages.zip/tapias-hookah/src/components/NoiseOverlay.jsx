import React from 'react'

export function NoiseOverlay(){
  return <div className="noise" aria-hidden="true" />
}

